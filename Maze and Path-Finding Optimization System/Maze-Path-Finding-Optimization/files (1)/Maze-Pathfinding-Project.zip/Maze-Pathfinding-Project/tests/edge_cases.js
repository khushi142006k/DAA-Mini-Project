const fs=require('fs');
const els={};const mk=()=>({value:'41',checked:false,style:{},tBodies:[{}],children:[],innerHTML:'',getContext:()=>new Proxy({}, {get:()=>()=>{},set:()=>true}),width:620,addEventListener(){},textContent:''});
global.document={getElementById:i=>els[i]||(els[i]=mk())};
global.requestAnimationFrame=f=>setTimeout(f,0);
global.performance=require('perf_hooks').performance;
let src=fs.readFileSync(__dirname+'/../script.js','utf8');
src+=`
let okPerfect=0, okBlocked=0, T=100;
for(let t=0;t<T;t++){
  els.size.value=['15','25','41','61'][t%4]; els.loops.value='0'; els.weighted.checked=false;
  newMaze();
  const r=Object.values(ALGOS).map(f=>f());
  const same=r.every(x=>x.found&&x.steps===r[0].steps&&x.path.join()===r[0].path.join());
  if(same) okPerfect++;
  // block the end cell completely
  for(const [dr,dc] of DIRS){const a=E[0]+dr,b=E[1]+dc; if(a>=0&&b>=0&&a<N&&b<N&&!(a===S[0]&&b===S[1])) grid[a][b]=0;}
  const q=Object.values(ALGOS).map(f=>f());
  if(q.every(x=>!x.found&&x.path.length===0)) okBlocked++;
}
console.log('perfect maze, identical path from all 4:',okPerfect+'/'+T,'| blocked end -> no path for all 4:',okBlocked+'/'+T);
`;
eval(src);
