const fs=require('fs');
const els={};const mk=()=>({value:'41',checked:false,style:{},tBodies:[{}],children:[],innerHTML:'',getContext:()=>new Proxy({}, {get:()=>()=>{},set:()=>true}),width:620,addEventListener(){},textContent:''});
global.document={getElementById:i=>els[i]||(els[i]=mk())};
global.requestAnimationFrame=f=>setTimeout(f,0);
global.performance=require('perf_hooks').performance;
let src=fs.readFileSync(__dirname+'/../script.js','utf8');
src+=`
const out=[];
for(const w of [false,true]) for(const sz of ['15','25','41','61']){
  els.weighted.checked=w; els.loops.value='10'; els.size.value=sz;
  const acc={BFS:[0,0,0,0,0],DFS:[0,0,0,0,0],Dijkstra:[0,0,0,0,0],'A*':[0,0,0,0,0]}; const M=100;
  for(let t=0;t<M;t++){
    newMaze();
    const rs=Object.entries(ALGOS).map(([n,f])=>{f();const t0=performance.now();let r;for(let i=0;i<5;i++)r=f();r.ms=(performance.now()-t0)/5;return r});
    const best=Math.min(...rs.map(r=>r.cost));
    rs.forEach(r=>{const a=acc[r.name];a[0]+=r.steps;a[1]+=r.cost;a[2]+=r.explored;a[3]+=r.ms;a[4]+=(r.cost===best?1:0)});
  }
  out.push({w,sz,res:Object.fromEntries(Object.entries(acc).map(([k,a])=>[k,[a[0]/M,a[1]/M,a[2]/M,a[3]/M,a[4]/M*100].map(x=>+x.toFixed(3))]))});
}
console.log(JSON.stringify(out));
`;
eval(src);
