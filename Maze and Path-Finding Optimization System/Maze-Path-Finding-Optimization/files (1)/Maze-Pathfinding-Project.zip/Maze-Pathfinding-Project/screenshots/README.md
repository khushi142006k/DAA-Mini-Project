# Screenshots

Add your screenshots here (maze, animated search, race simulation, comparison table, C++ output) and reference them in the README.
